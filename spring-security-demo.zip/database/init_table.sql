drop table if exists t_user;

create table t_user (
  user_id varchar(50) primary key,
  user_password varchar(50),
  enabled tinyint(1)
)ENGINE=InnoDB;

insert into t_user(user_id, user_password, enabled) values ('lvfai', '15081508', true);