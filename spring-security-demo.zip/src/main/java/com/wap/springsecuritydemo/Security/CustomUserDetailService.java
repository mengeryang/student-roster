package com.wap.springsecuritydemo.Security;

import com.wap.springsecuritydemo.dao.User;
import com.wap.springsecuritydemo.dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

import java.util.Collection;

@Component
public class CustomUserDetailService implements UserDetailsService {
    private UserDao userDao;

    @Autowired
    public CustomUserDetailService(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public UserDetails loadUserByUsername(String userId) {
        User user = userDao.find(userId);
        Collection<? extends GrantedAuthority> authorities =
                AuthorityUtils.createAuthorityList("USER");

        return new org.springframework.security.core.userdetails.User(
                user.getUserId(),
                user.getPassword(),
                authorities
        );
    }
}
