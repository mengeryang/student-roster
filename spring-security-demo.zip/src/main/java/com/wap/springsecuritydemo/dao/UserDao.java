package com.wap.springsecuritydemo.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UserDao {
    private JdbcTemplate jdbcTemplate;

    final static private String FIND_SQL =
            "select user_id, user_password, enabled from t_user where user_id=?";

    @Autowired
    public UserDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public User find(String user_id) {
        try {
            return jdbcTemplate.queryForObject(FIND_SQL,
                    new Object[] {user_id},
                    (rs, i) -> new User(rs.getString(1),
                            rs.getString(2),
                            rs.getBoolean(3)));
        } catch (DataAccessException e) {
            return null;
        }
    }
}
